Nom d'etudiant(e): Victor Awogbemi
Numero d'etudiant: 300081904
Code de cours: ITI1521
Section de lab: A-1

Cette archive contient les 8 fichiers de lab 1, c'est-�-dire, ce fichier (README.txt),
puis les fichiers Q2.java, Q3_SquareArray.java, Q3_AverageDemo.java, Q3_ArrayInsertion.java, Q3_ReverseSortDemo.java, Q5.java, et Q6.java.