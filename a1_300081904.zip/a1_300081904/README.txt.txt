Nom(s)
Numéro(s) d'étudiant
Cote du cours
Numéro du devoir

* Intégrité dans les études

En soumettant ce devoir, je certifie que:

1. J'ai lu les règlements sur la fraude scolaire.

2. Je comprends les conséquences de la fraude scolaire.

3. Sauf pour le code source fourni par les instructeurs du cours,
   tout le code source soumis est le mien.

4. Je n'ai pas collaboré avec d'autres personnes, �  l'exception de
   ma coéquipière dans le cas d'un travail en équipe (de deux personnes).

       Si vous avez collaboré avec d'autres personnes ou si vous
       avez obtenu du code source du Web, veuillez soit donner les noms
       de vos collaborateurs ou vos sources, ainsi que la nature de la
       collaboration. Mettez ces informations dans le fichier
       README.txt. Des points seront retranchés proportionnellement � 
       l'aide reçue (0 �  100%).

***
Victor
300081904
Course number and section, if applicable, i.e. ITI 1121-A
The assignment number

* Academic Integrity

By submitting this assignment, I acknowledge:

1. I have read the academic regulations regarding academic fraud.

2. I understand the consequences of plagiarism.

3. With the exception of the source code provided by the instructors
   for this course, all the source code is mine.

4. I did not collaborate with any other person, with the exception of
   my partner in the case of team work.

   If you did collaborate with others or obtained source code from the
   Web, then please list the names of your collaborators or the source
   of the information, as well as the nature of the collaboration. Put
   this information in the submitted README.txt file. Marks will be
   deducted proportional to the level of help provided (from 0 to
   100%).