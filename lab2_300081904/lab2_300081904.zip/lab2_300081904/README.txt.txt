Nom d'etudiant(e): Victor Awogbemi
Numero d'etudiant: 300081904
Code de cours: ITI1121
Section de lab: A-2
Cette archive contient les 3 fichiers de lab 2, c'est-�-dire, ce fichier (README.txt),
puis les fichiers Combination.java et DoorLock.java.