Nom de l'�tudiante ou de l'�tudiant: Victor Awogbemi
Num�ro d'�tudiant: 300081904
Code du cours: ITI1521
Section de laboratoire: A02

Cette archive contient les 5 fichiers du laboratoire 9.

Sp�cifiquement, ce fichier (README.txt), ainsi que
Queue.java, ArrayQueue.java, Customer.java, Cashier.java.
