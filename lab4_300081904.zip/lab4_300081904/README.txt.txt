
Nom d'�tudiant(e): Victor Awogbemi
Numero d'�tudiant: 300081904
Code de cours: ITI1521
Section de lab: A-1

Cette archive contient les 6 fichiers de lab 4, c'est-�-dire, ce fichier (README.txt),
puis les fichiers Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.