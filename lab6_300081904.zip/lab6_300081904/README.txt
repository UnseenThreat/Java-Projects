Nom de l'�tudiante ou de l'�tudiant: Victor Awogbemi
Num�ro d'�tudiant: 300081904
Code du cours: ITI1521
Section de laboratoire: A02

Cette archive contient les 7 fichiers du laboratoire 6.

Sp�cifiquement, ce fichier (README.txt), ainsi que
ArrayStack.java, Dictionary.java, DynamicArrayStack.java, Pair.java, Map.java, Stack.java.