Nom de l'�tudiante ou de l'�tudiant: Victor Awogbemi
Num�ro d'�tudiant: 300081904
Code du cours: ITI1521
Section de laboratoire: A01

Cette archive contient les 6 fichiers du laboratoire 7.

Sp�cifiquement, ce fichier (README.txt), ainsi que
Controller.java, Timer.java, View.java, TextView.java, GraphicalView.java.