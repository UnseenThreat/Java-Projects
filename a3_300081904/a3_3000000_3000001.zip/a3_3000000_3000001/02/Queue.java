public interface Queue<E> {
 
 // YOUR CODE HERE
}
