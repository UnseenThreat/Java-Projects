import java.util.Random;

public class GameModel {

  // YOUR CODE HERE

}
