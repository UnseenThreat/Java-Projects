public class QueueImplementation<E> implements Queue<E> {

 // YOUR CODE HERE
}
