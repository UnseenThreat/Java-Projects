public class GameModel {

 // Your code here

}
