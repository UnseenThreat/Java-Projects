Nom de l'�tudiante ou de l'�tudiant: Victor Awogbemi
Num�ro d'�tudiant: 300081903
Code du cours: ITI1521
Section de laboratoire: A01

Cette archive contient les 7 fichiers du laboratoire 8.

Sp�cifiquement, ce fichier (README.txt), ainsi que
RandomExceptions.Java, Account.java, NotEnoughMoneyException.java, Map.java, Pair.java, Dictionary.java.