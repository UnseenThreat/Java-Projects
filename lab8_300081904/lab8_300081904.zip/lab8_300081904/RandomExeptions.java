import java.io.IOException;

public class RandomExceptions {

   public static void main(String args[]) {

      int exceptionNumber = randomNumber();

      try{
	        throwException(exceptionNumber);
      }
      // Your code here to catch exceptions one by one.
   }

   public static int randomNumber() {
      return (int)(Math.random()*5) + 1;
   }

   public static void throwException(int exceptionNumber) throws Exception, IOException{
      if(exceptionNumber==1){
	       // Your code here
      }
      if(exceptionNumber==2){
	       // Your code here
      }
      if(exceptionNumber==3){
	       // Your code here
      }
      if(exceptionNumber==4){
	       // Your code here
      }
      if(exceptionNumber==5){
	       // Your code here
      }
   }
}