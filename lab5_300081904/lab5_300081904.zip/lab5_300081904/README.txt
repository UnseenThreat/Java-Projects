Nom de l'�tudiante ou de l'�tudiant: Victor Awogbemi
Num�ro d'�tudiant: 300081904
Code du cours: ITI1521
Section de laboratoire: A01

Cette archive contient les 8 fichiers du laboratoire 5.

Sp�cifiquement, ce fichier (README.txt), ainsi que
AbstractSeries.java, Arithmetic.java, Book.java, BookComparator.java, Geometric.java,
Library.java, Series.java.